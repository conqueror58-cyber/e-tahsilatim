---
name: MakbuzPro Finansal Arayüz Sistemi
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#006c4a'
  on-secondary: '#ffffff'
  secondary-container: '#82f5c1'
  on-secondary-container: '#00714e'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#40000c'
  on-tertiary-container: '#f83256'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#ffdada'
  tertiary-fixed-dim: '#ffb3b6'
  on-tertiary-fixed: '#40000c'
  on-tertiary-fixed-variant: '#920028'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  numeric-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.03em
  numeric-table:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-sm: 0.75rem
  margin-lg: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system delivers a refined, uncompromisingly trustworthy, and high-efficiency financial management interface tailored for Turkish B2B commerce, accounting workflows, and field operations. Built to digitize physical receipt-book ecosystems (*tahsilat ve tediye makbuzları*), current-account balances (*cari hesap mutabakatı*), and multi-instrument fiscal tracking (*çek, senet, havale/EFT*), the visual tone balances institutional authority with swift mobile ergonomics.

The aesthetic blends **Modern Corporate Fintech** with **High-Density Precision**. Rather than generic consumer playfulness, the interface conveys reliability, audit-grade discipline, and tactile clarity. High-contrast financial indicators immediately separate receivables (*tahsilat/giriş*) from obligations (*tediye/çıkış*), eliminating cognitive lag for busy field representatives, accountants, and SME executives operating in high-volume commercial environments.

## Colors

The palette establishes immediate fiscal clarity through structural division of ledger movements:

- **Primary (`#0F172A` - Slate Navy):** Anchors primary brand touchpoints, top navigation bars, structural titles, primary active states, and bottom navigation frames. Communicates enterprise security and administrative authority.
- **Secondary (`#059669` - Enterprise Emerald):** Governs collections (*Tahsilat*), positive balances, settled inflows, and primary confirmation calls to action. Accompanied by `#ECFDF5` for subtle badge fills.
- **Tertiary (`#E11D48` - Crimson Rose):** Reserved exclusively for disbursements (*Tediye*), payment outflows, overdue alerts, and destructive validation states. Paired with `#FFF1F2` for soft status backdrops.
- **Neutral Palette:**
  - `#020617` (Deep Ink) for critical numerical totals and ledger data.
  - `#64748B` (Slate Grey) for field metadata, Turkish tax numbers (VKN/TCKN), and secondary annotations.
  - `#CBD5E1` (Border Stroke) for hairline separators and field boundaries.
  - `#F1F5F9` (Muted Foundation) for segmented pickers, inactive cards, and grouped item backings.
  - `#F8FAFC` (Canvas Foundation) for the primary application background.
  - `#FFFFFF` (Card Elevated) for surface tiles, modal sheets, and receipt slips.
- **Instrument Identifiers (Custom Tags):**
  - *Nakit (Cash):* Deep Mint `#047857` on `#D1FAE5`.
  - *Kredi Kartı (Card):* Cobalt `#1D4ED8` on `#DBEAFE`.
  - *Çek (Check):* Amber Indigo `#4338CA` on `#EEF2FF`.
  - *Senet (Promissory Note):* Ochre `#B45309` on `#FEF3C7`.

## Typography

Typographic scale is powered by **Plus Jakarta Sans**, selected for its geometric structural rigor, balanced ascenders/descenders, and superior legibility within data-heavy tabular screens. 

### Special Considerations:
- **Turkish Diacritics Support:** Full native support for characters (`ç, ğ, ı, İ, ö, ş, ü`) ensures seamless rendering across customer names (*Cari Ünvanı*) and official tax descriptions.
- **Tabular Numerics:** All currency figures, IBAN fields, VKN/TCKN inputs, and document serial IDs must enforce tabular figures (`font-variant-numeric: tabular-nums;`) to guarantee columnar vertical alignment inside balance tables.
- **Currency Convention:** Standard formatting strictly follows Turkish accounting syntax: thousands separated by periods, decimals by commas, suffixed with the official Turkish Lira symbol (e.g., `₺142.850,50` or `142.850,50 TL`).

## Layout & Spacing

The layout philosophy emphasizes rapid data ingestion, thumbs-first mobile action zones, and seamless adaptation from edge-to-edge compact screens (360px+) to tablets used at point-of-sale desks.

- **Grid Architecture:** 
  - **Mobile:** 4-column layout with `margin: 1rem` (16px) and `gutter: 0.75rem` (12px). Full-width structured cards host dense financial rows.
  - **Tablet / Field Terminal (600px - 1024px):** 8-column layout with `margin: 1.5rem` (24px) and `gutter: 1rem` (16px), enabling side-by-side split screens (ledger list on the left, interactive receipt draft preview on the right).
- **Rhythm & Padding:** All element spacing strictly adheres to an 8pt spatial grid with 4pt steps for internal form and badge structures (`space-xs: 4px`, `space-sm: 8px`, `space-md: 16px`, `space-lg: 24px`, `space-xl: 32px`).
- **Safe Zones:** Mobile bottom margins explicitly account for a 64px persistent navigation bar plus safe area insets to prevent floating action overlaps.

## Elevation & Depth

This system avoids theatrical, distracting drop shadows in favor of **Crisp Tonal Layering** combined with calibrated **Ambient Micro-Shadows**.

- **Level 0 (Floor Canvas):** `#F8FAFC`. Zero elevation, matte textured substrate for general application scroll canvas.
- **Level 1 (Card & Row Surfaces):** Pure White `#FFFFFF` framed with a 1px solid stroke (`#E2E8F0`). Enhanced with micro-depth: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Active Sheets & Quick Action Tiles):** Elevated cards, dropdown popovers, and sticky subheaders. Shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`.
- **Level 3 (Modals & Bottom Drawers):** Receipt issuance confirmation trays, filters, and digital signature pads. Framed with `0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.08)` complemented by a 30% alpha slate backdrop overlay (`rgba(15, 23, 42, 0.40)`).
- **Receipt Slip Visual Metaphor:** Receipt summary modules (*Makbuz Önizleme*) utilize pure white containers with subtle perforated edge motifs or a distinctive top colored ledger-bar (emerald for collection, rose for disbursement).

## Shapes

The design system incorporates **Roundedness Level 2** (`0.5rem` / 8px baseline radius), establishing an optimal balance between contemporary software elegance and business software sobriety:

- **Base Radius (`0.5rem` / 8px):** Inputs, select menus, monetary input groups, search fields, table row action segments.
- **Container Radius (`rounded-lg` / `1rem` / 16px):** Primary ledger summary cards, receipt preview modules, bottom sheets, summary KPI carousels.
- **Deep Radius (`rounded-xl` / `1.5rem` / 24px):** Floating bottom sheets, persistent navigation bar envelopes.
- **Capsule / Pill Radius (`full` / 9999px):** Instrument badges (*Nakit, Çek, Senet*), settlement tags (*Tahsil Edildi, İade, Vadesi Geçmiş*), and quick date-filter pills.

## Components

### 1. Buttons & Triggers
- **Primary Action (Tahsilat / Inflow):** Solid Emerald (`#059669`) background with white text, 48px height on mobile for accessible thumb targets, 8px border radius. Hover/Pressed: `#047857`.
- **Secondary Action (Tediye / Outflow):** Solid Rose (`#E11D48`) or bordered variant for payment orders. Pressed: `#BE123C`.
- **Neutral Administrative:** Deep Navy (`#0F172A`) for receipt generation, export (PDF/Excel), and official e-Sign submission.
- **Tertiary / Ghost:** Transparent background with `#0F172A` text and `#E2E8F0` border for cancellation, receipt history lookup, and draft saving.

### 2. Payment Instrument Badges (Ödeme Türü Etiketleri)
- Fixed height: 24px. Padding: 4px 10px. Font: `label-sm` (10px, semi-bold, uppercase, letter-spacing +0.04em).
- **Nakit (Cash):** Background `#ECFDF5`, text `#047857`, dot indicator `#10B981`.
- **Kredi Kartı (Credit Card):** Background `#EFF6FF`, text `#1D4ED8`, dot indicator `#3B82F6`.
- **Çek (Bank Check):** Background `#EEF2FF`, text `#4338CA`, dot indicator `#6366F1`. Includes bank name and maturity date (*Vade*) in subtext.
- **Senet (Promissory Note):** Background `#FEF3C7`, text `#92400E`, dot indicator `#F59E0B`.

### 3. Financial Input Fields
- Structured border (`#CBD5E1`), 48px touch boundary, active ring with `#0F172A` at 2px stroke.
- **Currency Field (Tutar Girişi):** Always incorporates a fixed left prefix badge (`₺` or `TL`) with bold, auto-formatting numeral font (`numeric-table`).
- **Company / Tax Number Auto-Lookup (VKN/TCKN):** Text input with inline status trigger verifying against Turkish Revenue Administration (*GİB*) conventions, displaying matched official title in an attached slate preview chip.

### 4. Current-Account Cards (Cari Kart & Makbuz Listesi)
- White surface (`#FFFFFF`) with 1px slate-200 boundary.
- **Left Column:** Client title (*Ünvan*), receipt code (`MK-2024-00891`), relative timestamp, and instrument pill.
- **Right Column:** Large tabular financial balance. Inflows displayed in bold `#059669` prefixed with `+`, outflows displayed in `#E11D48` prefixed with `-`.
- **Swipe Actions:** Quick left-swipe on mobile reveals "Makbuz Yazdır" (Print/PDF) and "Paylaş" (WhatsApp/Email PDF receipt link).

### 5. Check & Promissory Note Cards (Çek / Senet Portföyü)
- Distinct document card with dashed secondary border styling.
- Clearly displays Draw-Date (*Keşide Tarihi*), Maturity Date (*Vade Tarihi*), Bank/Branch, and Drawer (*Keşideci*).
- Status alerts: Amber highlight when maturity is within ≤ 3 days, red when overdue.

### 6. Bottom Navigation Bar
- Fixed 64px height with frosted enterprise backing (`rgba(255, 255, 255, 0.94)` with 12px blur) and 1px top hairline (`#E2E8F0`).
- Five primary anchors: **Ana Sayfa** (Overview), **Cariler** (Accounts), **Hızlı Makbuz (+)** (Elevated circular primary button in `#0F172A`), **Kasa/Banka** (Cash & Banking), and **Raporlar** (Ledger Reports).